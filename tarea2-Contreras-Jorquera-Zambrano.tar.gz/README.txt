Instrucciones compilación Tarea 2

listas.c corresponde a la parte de listas de la tarea
arbol.c corresponde a la parte de arbol de búsqueda binario

Asegurarse de compilar usando el flag -lm para no tener problemas con math.h en arbol.c
Comando ejemplo:
- gcc -Wall arbol.c -o prueba -lm
